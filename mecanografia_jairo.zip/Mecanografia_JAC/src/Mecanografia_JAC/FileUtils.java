package Mecanografia_JAC;

import java.io.*;
import java.util.*;

public class FileUtils {
    private static final String RUTA_ARCHIVO = "src/Archivos/usuarios.txt";
    private static final String USUARIO_ADMIN = "a";
    private static final String CONTRASEÑA_ADMIN = "a";
    private static final int MAX_USUARIOS = 5;

    // Cargar usuarios desde el archivo
    public static List<User> cargarUsuarios() {
        List<User> usuarios = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RUTA_ARCHIVO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    usuarios.add(new User(partes[0], partes[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar usuarios: " + e.getMessage());
        }

        // Asegurar que el administrador siempre está presente
        boolean adminExiste = usuarios.stream().anyMatch(u -> u.getNombre().equals(USUARIO_ADMIN));
        if (!adminExiste) {
            usuarios.add(new User(USUARIO_ADMIN, CONTRASEÑA_ADMIN));
            guardarUsuarios(usuarios);
        }

        return usuarios;
    }

    // Guardar todos los usuarios en el archivo
    public static void guardarUsuarios(List<User> usuarios) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RUTA_ARCHIVO))) {
            for (User u : usuarios) {
                pw.println(u.getNombre() + "," + u.getContraseña());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar usuarios: " + e.getMessage());
        }
    }

    // Guardar un solo usuario nuevo
    public static boolean guardarUsuario(User usuario) {
        List<User> usuarios = cargarUsuarios();

        // Verificar si ya hay 5 usuarios (excluyendo al admin)
        long totalUsuarios = usuarios.stream().filter(u -> !u.getNombre().equals(USUARIO_ADMIN)).count();
        if (totalUsuarios >= MAX_USUARIOS) {
            return false;
        }

        // Agregar el nuevo usuario si no excede el límite
        usuarios.add(usuario);
        guardarUsuarios(usuarios);
        return true;
    }

    // Eliminar un usuario (excepto el admin)
    public static boolean eliminarUsuario(String nombre) {
        if (nombre.equals(USUARIO_ADMIN)) {
            return false;  // No se puede eliminar el admin
        }

        List<User> usuarios = cargarUsuarios();
        usuarios.removeIf(u -> u.getNombre().equals(nombre));
        guardarUsuarios(usuarios);
        return true;
    }
}
