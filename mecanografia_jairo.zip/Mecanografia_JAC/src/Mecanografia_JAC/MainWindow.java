package Mecanografia_JAC;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MainWindow extends JFrame {
    private JPanel panelLogin, panelMenu, panelCarga, panelAdmin;
    private JTextField campoUsuario;
    private JPasswordField campoContraseña;
    private String usuarioLogged;

    public MainWindow() {
        setIconImage(Toolkit.getDefaultToolkit().getImage("src/Imagenes/AppSimbol.png"));
        setTitle("MecaLife");
        setBounds(100, 100, 450, 300);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new CardLayout());
        
        

        panelCarga = new Carga(() -> mostrarPanel("Login"));
        panelLogin = crearPanelLogin();
        panelMenu = crearPanelMenu();
        panelAdmin = crearPanelAdmin();

        getContentPane().add(panelCarga, "Carga");
        getContentPane().add(panelLogin, "Login");
        getContentPane().add(panelMenu, "Menu");
        getContentPane().add(panelAdmin, "Admin");

        mostrarPanel("Carga");

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                int confirm = JOptionPane.showConfirmDialog(null, "¿Está seguro de que quiere salir?", "Confirmar salida", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
    }

    private JPanel crearPanelLogin() {
        JPanel panel = new JPanel(null);
        panel.setBackground(Color.CYAN);

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(150, 50, 100, 25);
        panel.add(lblUsuario);

        campoUsuario = new JTextField();
        campoUsuario.setBounds(250, 50, 200, 25);
        panel.add(campoUsuario);

        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setBounds(150, 100, 100, 25);
        panel.add(lblPassword);

        campoContraseña = new JPasswordField();
        campoContraseña.setBounds(250, 100, 200, 25);
        panel.add(campoContraseña);

        JButton btnLogin = new JButton("Ingresar");
        btnLogin.setBounds(250, 150, 100, 30);
        btnLogin.addActionListener(e -> validarCredenciales());
        panel.add(btnLogin);

        return panel;
    }

    private void validarCredenciales() {
        String usuario = campoUsuario.getText().trim();
        String password = new String(campoContraseña.getPassword()).trim();

        if ("a".equals(usuario) && "a".equals(password)) {
            usuarioLogged = usuario;
            mostrarPanel("Admin");
            return;
        }

        List<User> usuarios = FileUtils.cargarUsuarios();
        boolean usuarioValido = usuarios.stream().anyMatch(u -> u.getNombre().equals(usuario) && u.getContraseña().equals(password));

        if (usuarioValido) {
            usuarioLogged = usuario;
            mostrarPanel("Menu");
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel crearPanelMenu() {
        JPanel panel = new JPanel(new GridLayout(3, 1));
        panel.setBackground(Color.GREEN);

        JLabel lblMenu = new JLabel("Seleccione el nivel de práctica", SwingConstants.CENTER);
        lblMenu.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(lblMenu);

        JMenuBar menuBar = new JMenuBar();
        JMenu menuArchivo = new JMenu("Menú");
        JMenuItem menuAyuda = new JMenuItem("Ayuda");
        JMenuItem menuInfo = new JMenuItem("Info");
        menuAyuda.addActionListener(e -> mostrarPanelConImagen());
        menuInfo.addActionListener(e -> JOptionPane.showMessageDialog(this, "Nombre de la aplicación: MecaLife\nVersión: V1.0\nAutor: Ismae Lozano González\nInformación: La aplicación aún está en fase BETA, por lo que algunas funcionalidades aún no están disponibles, como el correo, las estadísticas y el cálculo de las PPM.\nEstas características se incluirán en futuras versiones.", "Info", JOptionPane.INFORMATION_MESSAGE));
        menuArchivo.add(menuInfo);
        menuArchivo.add(menuAyuda);
        menuBar.add(menuArchivo);
        setJMenuBar(menuBar);

        JButton btnFacil = new JButton("Nivel Fácil");
        btnFacil.addActionListener(e -> cargarLeccion("facil"));
        panel.add(btnFacil);

        JButton btnDificil = new JButton("Nivel Difícil");
        btnDificil.addActionListener(e -> cargarLeccion("dificil"));
        panel.add(btnDificil);

        return panel;
    }

    private void cargarLeccion(String nivel) {
        String texto = NivelPractica.cargarTexto(nivel);
        int tiempo = nivel.equals("facil") ? 240 : 180;

        JPanel practicaPanel = new Practica(texto, tiempo, 5, completado -> {
            if (completado) {
                mostrarPanel("Logro");
            } else {
                JOptionPane.showMessageDialog(this, "No completaste el texto a tiempo.", "Error", JOptionPane.ERROR_MESSAGE);
                mostrarPanel("Menu");
            }
        });

        getContentPane().add(practicaPanel, "Practica");
        mostrarPanel("Practica");
    }

    private JPanel crearPanelAdmin() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.YELLOW);

        JLabel lblAdmin = new JLabel("Administrar Usuarios", SwingConstants.CENTER);
        lblAdmin.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(lblAdmin, BorderLayout.NORTH);

        DefaultListModel<String> modeloLista = new DefaultListModel<>();
        JList<String> listaUsuarios = new JList<>(modeloLista);
        FileUtils.cargarUsuarios().forEach(u -> modeloLista.addElement(u.getNombre()));
        panel.add(new JScrollPane(listaUsuarios), BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new BorderLayout());
        JPanel panelCampos = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelCampos.add(new JLabel("Nuevo Usuario:"));
        JTextField txtNuevoUsuario = new JTextField(10);
        panelCampos.add(txtNuevoUsuario);

        panelCampos.add(new JLabel("Contraseña:"));
        JPasswordField txtNuevoPassword = new JPasswordField(10);
        panelCampos.add(txtNuevoPassword);

        panelInferior.add(panelCampos, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton btnAgregar = new JButton("Agregar Usuario");
        JButton btnEliminar = new JButton("Eliminar Usuario");
        JButton btnVolverLogin = new JButton("Volver al Login");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnVolverLogin);

        panelInferior.add(panelBotones, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> {
            String nombre = txtNuevoUsuario.getText().trim();
            String pass = new String(txtNuevoPassword.getPassword()).trim();

            if (!nombre.isEmpty() && !pass.isEmpty()) {
                if (FileUtils.cargarUsuarios().size() < 6) {
                    if (FileUtils.guardarUsuario(new User(nombre, pass))) {
                        modeloLista.addElement(nombre);
                        txtNuevoUsuario.setText("");
                        txtNuevoPassword.setText("");
                        JOptionPane.showMessageDialog(this, "Usuario agregado con éxito.");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se pueden agregar más de 5 usuarios.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "No se pueden agregar más de 5 usuarios.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Debe completar ambos campos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            String usuarioSeleccionado = listaUsuarios.getSelectedValue();
            if (usuarioSeleccionado != null) {
                if (FileUtils.cargarUsuarios().size() > 4) {
                    if (!usuarioSeleccionado.equals("a")) {
                        if (FileUtils.eliminarUsuario(usuarioSeleccionado)) {
                            modeloLista.removeElement(usuarioSeleccionado);
                            JOptionPane.showMessageDialog(this, "Usuario eliminado con éxito.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "No se puede eliminar el administrador.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Debe haber al menos 3 usuarios.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un usuario para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnVolverLogin.addActionListener(e -> mostrarPanel("Login"));

        panel.add(panelInferior, BorderLayout.SOUTH);
        return panel;
    }

    private void mostrarPanel(String nombre) {
        CardLayout cardLayout = (CardLayout) getContentPane().getLayout();
        cardLayout.show(getContentPane(), nombre);
    }

    private void mostrarPanelConImagen() {
        try {
            ImageIcon icono = new ImageIcon("src/Imagenes/ImagenAyuda.png");
            JLabel etiqueta = new JLabel(icono);
            JOptionPane.showMessageDialog(this, etiqueta, "Ayuda", JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar la imagen de ayuda.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            MainWindow ventana = new MainWindow();
            ventana.setVisible(true);
        });
    }
}
