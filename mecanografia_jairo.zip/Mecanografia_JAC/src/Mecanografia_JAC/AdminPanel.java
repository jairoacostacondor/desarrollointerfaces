package Mecanografia_JAC;

import javax.swing.JPanel;

public class AdminPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public AdminPanel() {

	}

}
