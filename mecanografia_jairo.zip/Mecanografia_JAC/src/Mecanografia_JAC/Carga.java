package Mecanografia_JAC;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class Carga extends JPanel {
    private JProgressBar progressBar;
    private Timer timer;
    private int progress;

    public Carga(Runnable onFinish) {
        setLayout(new BorderLayout());

        // Ruta corregida para la imagen de fondo
        ImageIcon imagenFondo = new ImageIcon("src/Imagenes/App.png");
        if (!new File("src/Imagenes/App.png").exists()) {
            System.out.println("¡Error! La imagen App.png no se encuentra.");
        }

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Image imagenEscalada = imagenFondo.getImage().getScaledInstance(screenSize.width, screenSize.height,
                Image.SCALE_SMOOTH);
        JLabel labelFondo = new JLabel(new ImageIcon(imagenEscalada));
        labelFondo.setLayout(new BorderLayout());
        add(labelFondo, BorderLayout.CENTER);
        
        // Barra de progreso
        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(screenSize.width, 30));
        progressBar.setStringPainted(true);
        labelFondo.add(progressBar, BorderLayout.SOUTH);

        // Temporizador que incrementa la barra de progreso
        timer = new Timer(60, e -> {
            progress++;
            progressBar.setValue(progress);
            if (progress >= 100) {
                timer.stop();
                if (!verificarArchivosTxt()) {
                    mostrarErrorYSalir();
                } else {
                    onFinish.run();
                }
            }
        });
        timer.start();
    }

    // Verifica si los archivos necesarios existen
    private boolean verificarArchivosTxt() {
        String[] archivos = { "src/Archivos/usuarios.txt", "src/Archivos/leccion.txt" };

        for (String ruta : archivos) {
            File archivo = new File(ruta);
            if (!archivo.exists()) {
                System.out.println("¡Error! El archivo no se encuentra: " + ruta);
                return false;
            }
        }
        return true;
    }

    // Muestra mensaje de error y cierra la aplicación
    private void mostrarErrorYSalir() {
        JOptionPane.showMessageDialog(this, "Faltan archivos necesarios. La aplicación se cerrará.", "Error", JOptionPane.ERROR_MESSAGE);
        System.exit(0);  // Cierra la aplicación
    }
}
