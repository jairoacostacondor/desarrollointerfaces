/**
 * 
 */
/**
 * 
 */
module Proyecto_Mecanografia {
	requires java.desktop;
}